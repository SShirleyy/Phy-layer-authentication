import matplotlib.pyplot as plt
import numpy as np

mac_addr = list()
index = 0
result = [[] for i in range(20)]
filename = raw_input("Type the name of input file:")
F = open(filename,"r")
readFile = F.readlines()
for line in readFile:
	parts = line.split()
	if parts[0] in mac_addr:
		index = mac_addr.index(parts[0])
#		print index
		result[index].append(parts[1])
	else:
		mac_addr.append(parts[0])
		index = mac_addr.index(parts[0])
#		print index
#		if index == 0:
#			result.append(parts[1])
#		else:
#			result[index].append(parts[1])
		result[index].append(parts[1])
text1 = "Print the result:"
print text1
print result
#	print parts[1]
text2 = "Print Mac list:"
print text2
print mac_addr

F.close()

for j in range(len(mac_addr)):
#	plt.plot(np.asarray(result[j]), '^')
	plt.plot(np.asarray(result[j]), 's', label = mac_addr[j])
plt.legend()	
plt.grid()
plt.title('FO Variations for Different MAC Address from'+' '+ filename)
plt.xlabel('data frame number')
plt.ylabel('FO(Hz)')
plt.show()

