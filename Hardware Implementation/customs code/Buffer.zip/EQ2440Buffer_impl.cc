/* -*- c++ -*- */
/*
 * Copyright 2017 <+YOU OR YOUR COMPANY+>.
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "EQ2440Buffer_impl.h"
using namespace std;
#include <fstream>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iterator>

namespace gr {
  namespace EQ2440Module {

    EQ2440Buffer::sptr
    EQ2440Buffer::make()
    {
      return gnuradio::get_initial_sptr
        (new EQ2440Buffer_impl());
    }

    /*
     * The private constructor
     */
    EQ2440Buffer_impl::EQ2440Buffer_impl()
      : gr::block("EQ2440Buffer",
              gr::io_signature::make(0, 0, 0),
              gr::io_signature::make(0, 0, 0))
    {
      counter = 0;
      tmp = 0;
      gr::block::message_port_register_in(pmt::mp("bufferin"));
      gr::block::set_msg_handler(pmt::mp("bufferin"),
        boost::bind(&EQ2440Buffer_impl::Bufferin_func, this, _1));

      gr::block::message_port_register_out(pmt::mp("bufferout"));



    }

    /*
     * Our virtual destructor.
     */
    EQ2440Buffer_impl::~EQ2440Buffer_impl()
    {
    }

    void
    EQ2440Buffer_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
      /* <+forecast+> e.g. ninput_items_required[0] = noutput_items */
    }

    int
    EQ2440Buffer_impl::general_work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
      // const <+ITYPE+> *in = (const <+ITYPE+> *) input_items[0];
      // <+OTYPE+> *out = (<+OTYPE+> *) output_items[0];

      // Do <+signal processing+>
      // Tell runtime system how many input items we consumed on
      // each input stream.
      consume_each (noutput_items);

      // Tell runtime system how many output items we produced.
      return noutput_items;
    }

    void EQ2440Buffer_impl::Bufferin_func(pmt::pmt_t bufferin){

      double idin = pmt::to_double(bufferin);

      if (idin == 0){
        counter = counter+1;
        if (counter >= 3){
          pmt::pmt_t freq0 = pmt::from_long(0);
          message_port_pub(pmt::mp("bufferout"), freq0);
        }
      }else{
        counter = 0;
        pmt::pmt_t freq0 = pmt::from_long(0);
        message_port_pub(pmt::mp("bufferout"), freq0);

      }


      // sleep(0.5);
      // pmt::pmt_t freq1 = pmt::from_double(400);
      // message_port_pub(pmt::mp("bufferout"), freq1);
      // sleep(0.5);
      // pmt::pmt_t freq2 = pmt::from_double(300);
      // message_port_pub(pmt::mp("bufferout"), freq2);
    }

  } /* namespace EQ2440Module */
} /* namespace gr */
