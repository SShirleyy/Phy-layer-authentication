/* -*- c++ -*- */
/*
 * Copyright 2017 <+YOU OR YOUR COMPANY+>.
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "EQ2440_myfilesink_cpp_impl.h"

//#include <pmt/pmt.h>
using namespace std;
#include <fstream>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iterator>
// #include <ncurses>

namespace gr {
  namespace EQ2440Module {

    EQ2440_myfilesink_cpp::sptr
    EQ2440_myfilesink_cpp::make(std::string filenamel, std::string filenamer, bool write_booll, bool write_boolr)
    {
      return gnuradio::get_initial_sptr
        (new EQ2440_myfilesink_cpp_impl(filenamel, filenamer, write_booll, write_boolr));
    }

    /*
     * The private constructor
     */
    EQ2440_myfilesink_cpp_impl::EQ2440_myfilesink_cpp_impl(std::string filenamel, std::string filenamer, bool write_booll, bool write_boolr)
      : gr::block("EQ2440_myfilesink_cpp",
          gr::io_signature::make(0, 0, 0),
          gr::io_signature::make(0, 0, 0)),
          my_write_booll(write_booll),my_write_boolr(write_boolr),
          my_filenamel(filenamel),my_filenamer(filenamer)
    {
      //std::ofstream filel;
      //filel.open(filenamel);
      //std::ofstream filer;
      //filer.open(filenamer);
      //filel.open("leftfile2.txt");
      filel.open(filenamel.c_str());
      //filer.open("rightfile2.txt");
      filer.open(filenamer.c_str());
    //  filel << "Start writting to symbols interfaces......" << endl;
    //  filer << "Start writting to messages interfaces......" << endl;
    //  filel.open("/tmp/leftfile.txt");
    //  filer.open("/tmp/rightfile.txt");

      gr::block::message_port_register_in(pmt::mp("equalizedsymbols"));
      gr::block::set_msg_handler(pmt::mp("equalizedsymbols"),
        boost::bind(&EQ2440_myfilesink_cpp_impl::equalized_symbols_func, this, _1));

      gr::block::message_port_register_in(pmt::mp("decodedmessage"));

      gr::block::set_msg_handler(pmt::mp("decodedmessage"),
        boost::bind(&EQ2440_myfilesink_cpp_impl::decoded_msg_func, this, _1));

    }

    /*
     * Our virtual destructor.
     */
    EQ2440_myfilesink_cpp_impl::~EQ2440_myfilesink_cpp_impl()
    {

      filel.close();
      filer.close();
    }

    void
    EQ2440_myfilesink_cpp_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
      /* <+forecast+> e.g. ninput_items_required[0] = noutput_items */
    }

    int
    EQ2440_myfilesink_cpp_impl::general_work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
  //    const <+ITYPE+> *in = (const <+ITYPE+> *) input_items[0];
    //  <+OTYPE+> *out = (<+OTYPE+> *) output_items[0];

      // Do <+signal processing+>
      // Tell runtime system how many input items we consumed on
      // each input stream.
      consume_each (noutput_items);

      // Tell runtime system how many output items we produced.
      return noutput_items;
    }

    void EQ2440_myfilesink_cpp_impl::equalized_symbols_func(pmt::pmt_t symbols){

      //  sym_array = pmt.to_python(pmt::cdr(symbols));
        // pmt::pmt_t symbols_list = pmt::cdr(symbols);
        // std::string str = pmt::symbol_to_string(symbols_list);
        // filel << str <<  endl;
    //       this->filel << "writing" << endl;
    //
        if (my_write_booll){
          std::cout << "symbols port activated" << endl;
          pmt::pmt_t symbols_car = pmt::car(symbols);   // empty
          pmt::pmt_t symbols_cdr = pmt::cdr(symbols);

          std::vector<std::complex<float> > symbols_vec = pmt::c32vector_elements(symbols_cdr);
          std::vector<std::complex<float> >::iterator symbols_vec_iter;

          for(symbols_vec_iter=symbols_vec.begin();symbols_vec_iter!=symbols_vec.end();++symbols_vec_iter){
            // std::cout << *symbols_vec_iter << endl;
            filel << *symbols_vec_iter << endl;
          }

          // for (int i=0; i<symbols_vec.size();i++){
          //   std::cout << symbols_vec[i] << endl;
          // }

          // std::cout << "symbols is pair:" << pmt::is_pair(symbols) << endl;
          // std::cout << "symbols_car is dict:" << pmt::is_dict(symbols_car) << endl;
          // std::cout << "symbols_cdr is c32vector:" << pmt::is_c32vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is c64vector:" << pmt::is_c64vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is complex:" << pmt::is_complex(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is dict:" << pmt::is_dict(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is u8vector:" << pmt::is_u8vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is u16vector:" << pmt::is_u16vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is u32vector:" << pmt::is_u32vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is u64vector:" << pmt::is_u64vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is uniform_vector:" << pmt::is_uniform_vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is vector:" << pmt::is_vector(symbols_cdr) << endl;
          // std::cout << "symbols_cdr is complex:" << pmt::is_complex(symbols_cdr) << endl;
        }
    }


    void EQ2440_myfilesink_cpp_impl::decoded_msg_func(pmt::pmt_t messages){


      if (my_write_boolr){
        std::cout << "messages port activated" << endl;

        pmt::pmt_t messages_car = pmt::car(messages);
        pmt::pmt_t messages_cdr = pmt::cdr(messages);

        std::vector<uint8_t> cdr_temp = pmt::u8vector_elements(messages_cdr);

        filer << "dst mac: " ;
        for (int i=4; i<10;i++){
//          filer << nibble_to_hex(cdr_temp[i]);

            if (i<9){
              std::cout<< std::hex <<(int)cdr_temp[i] << ":";
              filer << std::hex << (int)cdr_temp[i] << ":";

            }else{
              std::cout<< std::hex <<(int)cdr_temp[i] << " | ";
              filer << std::hex << (int)cdr_temp[i] << " | " ;
            }

        }


        filer << "src mac:" ;
        for (int i=10; i<16;i++){
//          filer << nibble_to_hex(cdr_temp[i]);

            if(i<15){
              std::cout<<  std::hex  << (int)cdr_temp[i] << ":";
              filer << std::hex << (int)cdr_temp[i] << ":";
            }else{
              std::cout<<  std::hex  << (int)cdr_temp[i] << " | ";
              filer << std::hex << (int)cdr_temp[i] << " | ";
            }

        }

//         for (int i=10; i<16;i++){
//         //          filer << nibble_to_hex(cdr_temp[i]);
//
//             if(i<15){
//               std::cout<<  std::hex  << (int)cdr_temp[i] << ":";
//               filer << std::hex << (int)cdr_temp[i] << ":";
//             }else{
//               std::cout<<  std::hex  << (int)cdr_temp[i] << " ";
//               filer << std::hex << (int)cdr_temp[i] << " ";
//             }
//
//         }
//
//         for (int i=4; i<10;i++){
// //          filer << nibble_to_hex(cdr_temp[i]);
//
//             if (i<9){
//               std::cout<< std::hex <<(int)cdr_temp[i] << ":";
//               filer << std::hex << (int)cdr_temp[i] << ":";
//
//             }else{
//               std::cout<< std::hex <<(int)cdr_temp[i] << " ";
//               filer << std::hex << (int)cdr_temp[i] << " " ;
//             }
//
//         }
        std::cout << "snr:" << pmt::dict_ref(messages_car,pmt::string_to_symbol("snr"),pmt::string_to_symbol("not found")) << " | ";
        filer << "snr:" << pmt::dict_ref(messages_car,pmt::string_to_symbol("snr"),pmt::string_to_symbol("not found")) << " | ";
        std::cout << "frequency offsets:" << pmt::dict_ref(messages_car,pmt::string_to_symbol("freqofs"),pmt::string_to_symbol("not found")) << endl;
        filer << "frequency offsets:" << pmt::dict_ref(messages_car,pmt::string_to_symbol("freqofs"),pmt::string_to_symbol("not found")) << endl;
        // filer << pmt::write_string(messages_car) << endl;
        // std::cout << pmt::dict_ref(messages_car,pmt::string_to_symbol("freqofs"),pmt::string_to_symbol("not found")) << ' '<<'\n' ;
        // filer <<  pmt::dict_ref(messages_car,pmt::string_to_symbol("freqofs"),pmt::string_to_symbol("not found")) << ' '<<'\n';
        //
        double freqofs_sample =  pmt::to_double(pmt::dict_ref(messages_car,pmt::string_to_symbol("freqofs"),pmt::string_to_symbol("not found")));
        if (freqofs_sample > -30000 || freqofs_sample < -20000){
          //std::beep();  //raise the alarm
          // fprintf(stdout, "\aBeep!\n" );
        //  std::cout << "\a";
          // printf("%c",07);
        //  std::cout << "anomly!" << endl;

        }

        // std::cout << "message is pair:" << pmt::is_pair(messages) << endl;
        // std::cout << "messages_car is dict:" << pmt::is_dict(messages_car) << endl;
        // std::cout << "messages_cdr is c32vector:" << pmt::is_c32vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is c64vector:" << pmt::is_c64vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is complex:" << pmt::is_complex(messages_cdr) << endl;
        // std::cout << "messages_cdr is dict:" << pmt::is_dict(messages_cdr) << endl;
        // std::cout << "messages_cdr is u8vector:" << pmt::is_u8vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is u16vector:" << pmt::is_u16vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is u32vector:" << pmt::is_u32vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is u64vector:" << pmt::is_u64vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is uniform_vector:" << pmt::is_uniform_vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is vector:" << pmt::is_vector(messages_cdr) << endl;
        // std::cout << "messages_cdr is complex:" << pmt::is_complex(messages_cdr) << endl;

        //
        // int index;
        // for (index = 4; index<=10; index++){
        //   msg_cdr_temp.push_back(pmt::u8vector_ref(messages_cdr, index));
        // }
      

            }
    }

    char EQ2440_myfilesink_cpp_impl::nibble_to_hex(uint8_t byte) {
        assert(byte >= 0 && byte <= 15);

        char c = byte + '0';
        if (byte > 9)
            c += 'a' - '0' - 10;

        return c;
    }

  } /* namespace EQ2440Module */
} /* namespace gr */
